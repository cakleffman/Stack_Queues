public class MyQueue {
    
    private MyStack inStack;
    private MyStack outStack;
    
    
    public MyQueue() {
        inStack = new MyStack(5);
        outStack = new MyStack(5);
    }
    
    public void enqueue(String s) {
        inStack.push(s);
        System.out.println("'" + s + "' got added to the inStack :)");
    }
    
    public String dequeue() {
        
        if(outStack.empty()){
            while(!(inStack.empty())){
                outStack.push(inStack.pop());
            }
        }
        
        return outStack.pop();
    }
    
    public boolean empty() {
        
        if(inStack.empty() && outStack.empty()){
            System.out.println("The queue is empty!");
            return true;
        }
        return false;
    }
    
    public static void main(String[] args) {
        MyQueue a = new MyQueue();
        a.enqueue("hey");
        a.enqueue("how");
        a.enqueue("are");
        a.enqueue("you");
        
        while(!(a.empty())){
            System.out.println(a.dequeue());
        }
    }
}