public class MyStack {
    
    public String[] a;
    public int top;
    
    public MyStack(int initialCapacity) {
        a = new String[initialCapacity];
        this.top = -1;
    }
    
    public void push(String s) {
        int i = top + 1;
        a[i] = s;
        top++;
        
        if(top == a.length - 1){
            String[] temp = new String[a.length * 2];
            for(int j = 0; j < a.length; j++){
                temp[j] = a[j];
            }
            a = temp;
        }
         
    }
    
    public String pop() {
        // You have to write this method, this is just here so your code compiles.
        if(!empty()){
            this.top = this.top - 1;
            return a[top + 1];
        }
        return null;
    }
    
    
    public boolean empty() {
        // You have to write this method, this is just here so your code compiles.
        if(top == -1){
            return true;
        }
        return false;
    }
    
    public void Print(){
        if(empty()){
            System.out.println("Stack is empty!!");
        }
        else{
            for(int i = this.top; i >= 0; i--){
                System.out.println(a[i]);
            }
        }
    }
    
    public static void main(String[] args) {
        MyStack a = new MyStack(5);
       
        a.push("abc");
        a.push("def");
        a.push("ghi");
        a.push("jkl");
        a.push("mno");
        a.push("pqr");
        a.push("stu");
        a.Print();
        a.pop();
        System.out.println("--------------------------------");
        a.Print();
    }
}